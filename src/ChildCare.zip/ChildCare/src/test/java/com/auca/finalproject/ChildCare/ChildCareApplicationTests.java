package com.auca.finalproject.ChildCare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChildCareApplicationTests {

	@Test
	void contextLoads() {
	}

}
