package com.auca.finalproject.ChildCare.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.auca.finalproject.ChildCare.entities.District;

public interface DistrictDao extends JpaRepository<District, Integer>{

	public District findDistrictById(int id);
}
