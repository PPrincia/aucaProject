package com.auca.finalproject.ChildCare.renderHtml;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.auca.finalproject.ChildCare.entities.District;
import com.auca.finalproject.ChildCare.service.DistrictService;

@Controller
@RequestMapping("/districts")
public class DistrictControler {

	@Autowired
	DistrictService districtService;
	
	@GetMapping
	public String displayDistrict(Model model) {
		
		List<District> districts = districtService.findAllDistrict();
		model.addAttribute("allDistricts", districts);
		
		return "main/districtList";
	}
	
	@GetMapping("/new/{id}")
	public String displayDistrictForm(Model model, @PathVariable int id) {
		District aDistrict = new District();
		model.addAttribute("district", aDistrict);
		
		return "location/districtForm";
	}
	
	@PostMapping("/save/{id}")
	public String createDistrict(@Valid District district, @PathVariable int id) {
		districtService.saveDistrict(district, id);
		
		return "redirect:/districts";
	}
	
	@GetMapping("/update/{id}")
	public String displayUpdateForm(Model model, @PathVariable int id) {
		District aDistrict = districtService.findDistrictById(id);
		model.addAttribute("district", aDistrict);
		
		return "location/new-district";
		
	}
	
	@GetMapping("/delete")
	public String displayDeleteForm(@RequestParam("id") int theId) {
		District aDistrict = districtService.findDistrictById(theId);
		districtService.delete(aDistrict);
		
		return "redirect:/districts";
	}
	
}
