package com.auca.finalproject.ChildCare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.auca.finalproject.ChildCare.dao.UserAccountDao;
import com.auca.finalproject.ChildCare.entities.UserAccount;

@Service
public class SecurityService {
	
	@Autowired
	private UserAccountDao userAccountDao;
	
	public List<UserAccount> findAllUsers(){
		return userAccountDao.findAll();
	}

}
