package com.auca.finalproject.ChildCare.renderHtml;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auca.finalproject.ChildCare.entities.Parent;
import com.auca.finalproject.ChildCare.entities.Sector;
import com.auca.finalproject.ChildCare.service.ParentService;
import com.auca.finalproject.ChildCare.service.SectorService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@Controller
@RequestMapping("/parents")
public class ParentControler {

	@Autowired
	ParentService parentService;
	
	@Autowired
	SectorService sectorService;

	
	@GetMapping
	public String displayParent(Model model) {
		List<Parent> parents = parentService.findAllParent();
		model.addAttribute("allParents", parents);
		
		return "main/parentList";
	}
	
	@GetMapping("/new/{id}")
	public String displayParentForm(Model model, @PathVariable int id) {
		Parent aParent = new Parent();
		//List<Sector> sectors = sectorService.findAllSector();
		Sector aSector = sectorService.findSectorById(id);
		model.addAttribute("parent", aParent);
		model.addAttribute("sector", aSector);
		//model.addAttribute("allSectors", sectors);
		return "main/form";
	}
		
	
	@PostMapping("/save/{id}")
	public String createParent(@Valid Parent parent, @PathVariable int id) {
		
		
		System.out.println("Inside create parent, before service");
		//Parent newParent = parentService.saveParent(parent, sectorId);o
		parentService.saveParent(parent, id);
		System.out.println("success");
		return "redirect:/parents";
		
	}
	
	@GetMapping("/update/{id}")
	public String displayUpdateForm(Model model, @PathVariable int id) {
		Parent aParent = parentService.findParentById(id);
		model.addAttribute("parent", aParent);
		
		return "parents/new-parent";
	}
	
	@GetMapping("/delete")
	public String displayDeleteForm(@RequestParam("id") int theId) {
		Parent aParent = parentService.findParentById(theId);
		parentService.delete(aParent);
		
		return "redirect:/parents";
		
	}
	
}
