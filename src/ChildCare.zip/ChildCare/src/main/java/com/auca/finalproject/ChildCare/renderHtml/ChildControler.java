package com.auca.finalproject.ChildCare.renderHtml;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.auca.finalproject.ChildCare.entities.Child;
import com.auca.finalproject.ChildCare.entities.Disease;
import com.auca.finalproject.ChildCare.entities.Parent;
import com.auca.finalproject.ChildCare.service.ChildService;
import com.auca.finalproject.ChildCare.service.DiseaseService;
import com.auca.finalproject.ChildCare.service.ParentService;

@Controller
@RequestMapping("/children")
public class ChildControler {

	@Autowired
	private ChildService childService;
	
	@Autowired
	private ParentService parentService;
	
	@Autowired
	private DiseaseService diseaseService;
	
	@GetMapping
	public String displayChildren(Model model) {
		List<Child> children = childService.findAllChildren();
		model.addAttribute("allChildren", children);
		
		return "main/childList";
	}
	
	@GetMapping("/newChild/{id}")
	public String displayChildForm(Model model, @PathVariable int id) {
		Child aChild = new Child();
		Parent aParent = parentService.findParentById(id);
		model.addAttribute("child", aChild);
		model.addAttribute("parent", aParent);
		return "main/childForm";
	}
	
	@PostMapping("/save/{id}")
	public String createChild(@Valid Child child, @PathVariable int id) {
		System.out.println("Inside create parent, before service");
		childService.saveChild(child, id);
		System.out.println("sucess");
		return "redirect:/children";
	}
	
	@PostMapping("/aasign/{id}")
	public String assignDiseases(@PathVariable int id) {
		System.out.println("Inside create assign diseases, before service");
		Disease aDisease = diseaseService.findDiseaseById(id);
		System.out.println(aDisease);
		childService.addDiseases(id);
		System.out.println("successs");
		return "redirect:/children";
	}
	
	@GetMapping("/newDisease/{id}")
	public String displayChildList(Model model, @PathVariable int id) {
		List<Disease> diseases = diseaseService.findAllDiseases();
		Child aChild = childService.findChildById(id);
		model.addAttribute("child", aChild);
		model.addAttribute("allDiseases", diseases);
		return "illness/child-disease";
	}
	
	
	@GetMapping("/update/{id}")
	public String displayChildUpdateForm(Model model, @PathVariable int id) {
		Child aChild = childService.findChildById(id);
		model.addAttribute("child", aChild);
		
		return "parents/new-child";
	}
	
	@GetMapping("/delete")
	public String displayDelete(@RequestParam("id") int theId) {
		Child aChild = childService.findChildById(theId);
		childService.delete(aChild);
		
		return "redirect:/children";
	}
	
	@PostMapping("/{childId}/assign/{diseaseId}")
	public String assignDisease(@PathVariable int diseaseId, @PathVariable int childId) {
		childService.addDisease(diseaseId, childId);
		return "redirect:/children";
	}
}
