package com.auca.finalproject.ChildCare.entities;

public enum SeverityType {
	
	LOW("Low"), MEDIUM("Medium"), HIGH("High");
	
	private final String name;
	
	SeverityType(String name){
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
	
}
