package com.auca.finalproject.ChildCare.renderHtml;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.auca.finalproject.ChildCare.entities.Category;
import com.auca.finalproject.ChildCare.service.CategoryService;


@Controller
@RequestMapping("/categories")
public class CategoryControler {
	
	@Autowired
	private CategoryService categoryService;
	
	@GetMapping
	public String displayCategory(Model model) {
		List<Category> categories = categoryService.findAllCategories();
		model.addAttribute("allCategories", categories);
		
		return "main/categoryList";
	}
	
	@GetMapping("/new")
	public String displayCategoryForm(Model model) {
		Category aCategory = new Category();
		model.addAttribute("category", aCategory);
		
		return "illness/new-category";
	}
	
	@PostMapping("/save")
	public String saveCategory(Category category) {
		categoryService.saveCategory(category);
		
		return "redirect:/categories";
	}
	

}
