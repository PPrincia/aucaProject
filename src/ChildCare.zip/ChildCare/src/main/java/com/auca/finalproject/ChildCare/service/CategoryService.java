package com.auca.finalproject.ChildCare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.auca.finalproject.ChildCare.dao.CategoryDao;
import com.auca.finalproject.ChildCare.entities.Category;

@Service
public class CategoryService {

	@Autowired
	private CategoryDao categoryDao;
	
	public Category saveCategory(Category category) {
		return categoryDao.save(category);
	}
	
	public Category findCategoryById(Integer id) {
		return categoryDao.findCategoryById(id);
	}
	
	public List<Category> findAllCategories(){
		return categoryDao.findAll();
	}
}
