package com.auca.finalproject.ChildCare.renderHtml;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.auca.finalproject.ChildCare.entities.District;
import com.auca.finalproject.ChildCare.entities.Sector;
import com.auca.finalproject.ChildCare.service.DistrictService;
import com.auca.finalproject.ChildCare.service.SectorService;

@Controller
@RequestMapping("/sectors")
public class SectorControler {

	@Autowired
	SectorService sectorService;
	
	@Autowired
	DistrictService districtService;
	
	@GetMapping
	public String displaySector(Model model) {
		List<Sector> sectors = sectorService.findAllSector();
		model.addAttribute("allSectors", sectors);
		
		return "main/sectorList";
	}
	
	@GetMapping("/new/{id}")
	public String displaySectorForm(Model model, @PathVariable int id) {
		Sector aSector = new Sector();
		District aDistrict = districtService.findDistrictById(id);
		model.addAttribute("sector", aSector);
		model.addAttribute("district", aDistrict);
		
		return "location/sectorForm";
	}
	
	@PostMapping("/save/{id}")
	public String createSector(@Valid Sector sector, @PathVariable int id) {
		
		System.out.println("Inside create sector, before service");
		sectorService.saveSector(sector, id);
		System.out.println("sucess");
		return "redirect:/sectors";
	}
	
	@GetMapping("/update/{id}")
	public String displaySectorUpdateForm(Model model, @PathVariable int id) {
		Sector aSector = sectorService.findSectorById(id);
		model.addAttribute("sector", aSector);
		
		return "location/new-sector";
	}
	
	@GetMapping("/delete")
	public String displayDeleteForm(@RequestParam("id") int theId) {
		Sector aSector = sectorService.findSectorById(theId);
		sectorService.delete(aSector);
		
		return "redirect:/sectors";
	}
}
