package com.auca.finalproject.ChildCare.dto;

public interface ChartData {

	public String getLabel();
	public String getValue();
}
