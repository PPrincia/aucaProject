package com.auca.finalproject.ChildCare.renderHtml;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.auca.finalproject.ChildCare.entities.Child;
import com.auca.finalproject.ChildCare.entities.Disease;
import com.auca.finalproject.ChildCare.entities.SeverityType;
import com.auca.finalproject.ChildCare.service.ChildService;
import com.auca.finalproject.ChildCare.service.DiseaseService;

@Controller
@RequestMapping("/diseases")
public class DiseaseControler {

	@Autowired
	private DiseaseService diseaseService;
	
	@Autowired
	private  ChildService childSrvice;
	 
	@GetMapping
	public String displayDiseases(Model model) {
		List<Disease> diseases = diseaseService.findAllDiseases();
		model.addAttribute("allDiseases", diseases);
		return "main/diseaseList";
	}
	
	@GetMapping("/new/{id}")
	public String displayDiseaseForm(Model model, @PathVariable int id) {
		Disease aDisease = new Disease();
		model.addAttribute("disease", aDisease);
		model.addAttribute("severityTypes", SeverityType.values());
		return "main/diseaseForm";
	}
	
	@GetMapping("/newChild/{id}")
	public String displayChildList(Model model, @PathVariable int id) {
		List<Child> children = childSrvice.findAllChildren();
		Disease aDisease = diseaseService.findDiseaseById(id);
		model.addAttribute("disease", aDisease);
		model.addAttribute("allChildren", children);
		return "main/childDisease";
	}
	
	@PostMapping("/save/{id}")
	public String createDisease(@Valid Disease disease, @PathVariable int id) {
		diseaseService.saveDisease(disease, id);
		
		return "redirect:/diseases";
	}
	
	@GetMapping("/update/{id}")
	public String displayDiseaseUpdateForm(Model model, @PathVariable int id) {
		Disease aDisease = diseaseService.findDiseaseById(id);
		model.addAttribute("disease", aDisease);
		
		return "illness/new-disease";
	}
	
	@GetMapping("/delete")
	public String deleteDisease(@RequestParam("id") int theId) {
		Disease aDisease = diseaseService.findDiseaseById(theId);
		diseaseService.delete(aDisease);

        return "redirect:/diseases";
	}
	
	@PostMapping("/{diseaseId}/assign/{childId}")
	public String assignDisease(@PathVariable int diseaseId, @PathVariable int childId) {
		diseaseService.addPatient(diseaseId, childId);
		
		return "illness/child-disease";
	}
	
	
	
}
