package com.auca.finalproject.ChildCare.renderHtml;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.auca.finalproject.ChildCare.dao.UserAccountDao;
import com.auca.finalproject.ChildCare.entities.UserAccount;
import com.auca.finalproject.ChildCare.service.CustomerUserDetailService;
import com.auca.finalproject.ChildCare.service.SecurityService;

@Controller
@RequestMapping("/securities")
public class SecurityControler {

	@Autowired
	BCryptPasswordEncoder bCryptEncoder;
	
	@Autowired
	UserAccountDao userAccountDao;
	
	@Autowired
	CustomerUserDetailService customerUserDetailService;
	
	@Autowired
	SecurityService securityService;
	
	@GetMapping()
	public String displayUserForm(Model model) {
		UserAccount useraccount = new UserAccount();
		model.addAttribute("userAccount", useraccount);
		
		return "security/registration";
	}
	
	
	@GetMapping("/new")
	public String displayLoginForm() {
		
		return "security/login";
	}
	
	
	@PostMapping("/save")
	public String saveUser(@Valid UserAccount userAccount) {
		userAccount.setPassword(bCryptEncoder.encode(userAccount.getPassword()));
		userAccountDao.save(userAccount);
		
		return "security/login";
	}
	
	
	/*@PostMapping("/authenticate")
	public String signIn(String username, String password) {
		UserAccount userA = userAccountDao.findByUsername(username);
		System.out.println(userA);
		UserAccount userP = userAccountDao.findByPassword(password);
		System.out.println(userP);
		List<UserAccount> usersA = new ArrayList<>();
		usersA = securityService.findAllUsers();
		for(UserAccount userAccount : usersA) {
			if(userA.equals(userAccount.getUsername()) && userP.equals(userAccount.getPassword())) {
				System.out.println("good credentials");
				return "/home";
			}else {
				System.out.println("bad credentials");
				return "security/login";
			}
		}
		
		return " you are being authenticated";
	}*/
	
	
	
}
