package com.auca.finalproject.ChildCare.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.auca.finalproject.ChildCare.dao.ChildDao;
import com.auca.finalproject.ChildCare.entities.Child;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
public class ReportService {

	@Autowired
	ChildDao childDao;
	
	public String exportReport(String reportFormat) throws FileNotFoundException, JRException {
		String path = "C:\\Users\\HP\\Desktop\\Reports";
		List<Child> children = childDao.findAll();
		// load file and compile it
		File file = ResourceUtils.getFile("classpath:child.jrxml");
		JasperReport jasperReport = JasperCompileManager.compileReport(file.getAbsolutePath());
		JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(children);
	    Map<String, Object> parameters = new HashMap<>();
	    parameters.put("created by", "MCSOP");
	    JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dataSource);
	    if(reportFormat.equalsIgnoreCase("html")) {
	    	JasperExportManager.exportReportToHtmlFile(jasperPrint, path+"\\children.html");
	    }
	    if(reportFormat.equalsIgnoreCase("pdf")) {
	    	JasperExportManager.exportReportToHtmlFile(jasperPrint, path+"\\children.pdf");
	    }
	    
	    return "report generated in path: " + path; 
	}
}
