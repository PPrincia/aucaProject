package com.auca.finalproject.ChildCare.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.auca.finalproject.ChildCare.entities.Parent;

public interface ParentDao extends JpaRepository<Parent, Integer>{

	public Parent findByEmail(String email);

}
