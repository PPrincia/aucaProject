package com.auca.finalproject.ChildCare.renderHtml;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class newHome {

	@GetMapping("/welcome")
	public String displayHome() {
		return "main/newHome";
	}
	
	@GetMapping("/province")
	public String displayProvinceList() {
		return "main/provinceList";
	}
	
	@GetMapping("/district")
	public String displayDistrictList() {
		return "main/districtList";
	}
	
	@GetMapping("/sector")
	public String displaySectorList() {
		return "main/sectorList";
	}
	
	@GetMapping("/parent")
	public String displayParentList() {
		return "main/parentList";
	}
	
	@GetMapping("/child")
	public String displayChildrenList() {
		return "main/childList";
	}
	
	@GetMapping("/category")
	public String displayCategoryList() {
		return "main/categoryList";
	}
	
	/*
	@GetMapping("/registration")
	public String displayRegistrationForm() {
		return "security/registration";
	}
	*/
}
