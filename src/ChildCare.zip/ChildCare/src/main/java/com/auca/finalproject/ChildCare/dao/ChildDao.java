package com.auca.finalproject.ChildCare.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.auca.finalproject.ChildCare.dto.ChartData;
import com.auca.finalproject.ChildCare.entities.Child;


public interface ChildDao extends JpaRepository<Child, Integer>{

	@Query(nativeQuery = true, value = "select gender as label, count(*) as value from child group by gender")
	public List<ChartData> getChildStatus();
}
