package com.auca.finalproject.ChildCare.entities;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Child {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@NotBlank(message = "Must give a first name")
	@Size(min = 2, max = 50)
	private String firstName;
	
	@NotBlank(message = "Must give a last name")
	@Size(min = 2, max = 50)
	private String lastName;
	
	@NotBlank(message = "Must give a gender")
	@Size(min = 2, max = 10)
	private String gender;
	

	private Date dob;
	
	@JsonIgnore
	@ManyToOne(cascade = {CascadeType.DETACH, CascadeType.MERGE, 
			CascadeType.PERSIST, CascadeType.REFRESH})
	@JoinColumn(name = "parent_id")
	private Parent parent;

	@ManyToMany(fetch = FetchType.LAZY,
				cascade = {CascadeType.DETACH, CascadeType.MERGE,
							CascadeType.PERSIST, CascadeType.REFRESH})
	@JoinTable(name = "disease_child",
				joinColumns = @JoinColumn(name = "child_id"),
				inverseJoinColumns = @JoinColumn(name = "disease_id"))
	private List<Disease> diseases;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public List<Disease> getDiseases() {
		return diseases;
	}

	public void setDiseases(List<Disease> diseases) {
		this.diseases = diseases;
	}
	
	public void assignDisease(Disease disease) {
		if(diseases == null) {
			diseases = new ArrayList<>();
		}
		
		diseases.add(disease);
	}

	@Override
	public String toString() {
		return "Child [firstName=" + firstName + ", lastName=" + lastName + ", diseases=" + diseases + "]";
	}

	
	
}
