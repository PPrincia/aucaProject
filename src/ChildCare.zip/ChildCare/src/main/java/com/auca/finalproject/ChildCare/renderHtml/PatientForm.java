package com.auca.finalproject.ChildCare.renderHtml;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PatientForm {

	@GetMapping("/newForm")
	public String displayHome() {
		return "main/form";
	}
}
