package com.auca.finalproject.ChildCare.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.auca.finalproject.ChildCare.entities.UserAccount;

public interface UserAccountDao extends JpaRepository<UserAccount, Integer>{

	UserAccount findByUsername(String username);
	
	UserAccount findByPassword(String password);
}
