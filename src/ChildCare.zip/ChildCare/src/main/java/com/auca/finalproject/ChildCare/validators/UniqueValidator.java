package com.auca.finalproject.ChildCare.validators;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;

import com.auca.finalproject.ChildCare.dao.ParentDao;
import com.auca.finalproject.ChildCare.entities.Parent;

public class UniqueValidator implements ConstraintValidator<UniqueValue, String>{
	
	@Autowired
	ParentDao parentDao;

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {

		/*System.out.println("entered validation method....");
		
		Parent parent = parentDao.findByEmail(value);
		
		if(parent != null) 
			return false;
		else
			return true;*/
		return false;
	}

}
