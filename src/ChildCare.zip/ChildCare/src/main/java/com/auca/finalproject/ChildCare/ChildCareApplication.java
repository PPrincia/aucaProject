package com.auca.finalproject.ChildCare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChildCareApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChildCareApplication.class, args);
	}

}
