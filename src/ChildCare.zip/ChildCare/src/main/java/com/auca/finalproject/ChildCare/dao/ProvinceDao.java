package com.auca.finalproject.ChildCare.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.auca.finalproject.ChildCare.entities.Province;

public interface ProvinceDao extends JpaRepository<Province, Integer>{

	public Province findPorivnceById(int id);
}
