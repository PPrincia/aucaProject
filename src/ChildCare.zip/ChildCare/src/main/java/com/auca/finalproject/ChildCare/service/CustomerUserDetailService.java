package com.auca.finalproject.ChildCare.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.auca.finalproject.ChildCare.dao.UserAccountDao;
import com.auca.finalproject.ChildCare.entities.UserAccount;

@Service
public class CustomerUserDetailService implements UserDetailsService{

	@Autowired
	UserAccountDao userAccountDao;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		UserAccount userAcc = userAccountDao.findByUsername(username);
		
		if( userAcc == null) {
			throw new UsernameNotFoundException("User not found");
		}
		return userAcc;
	}
	
	@Transactional
	public Optional<UserAccount> loadUserById(Integer id){
		
		Optional<UserAccount> userAcc = userAccountDao.findById(id);
		if(userAcc == null) {
			throw new UsernameNotFoundException("User not found");
		}
		
		return userAcc;
	}
	
}
